Page({
  data:{

  },
  note: function () {
    wx.navigateTo({
      url: '../index/index'
    })
  },
  curriculum: function () {
    wx.navigateTo({
      url: '../curriculum/curriculum'
    })
  },
  bindViewTap: function () {
    wx.navigateTo({
      url: '../photo/photo'
    })
  },
})