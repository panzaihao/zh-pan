// pages/photo/photo.js
Page({
data:{
src2:''
},
  takePhoto() {
    this.ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        this.setData({
          src: res.tempImagePath
        })
      }
    })
  },
  backup() {
    wx.saveImageToPhotosAlbum({
      success(res) {
        src: res.tempImagePath
      }
    })
  },
  onLoad() {
    this.ctx = wx.createCameraContext()
  },
  upload(){
  wx.chooseImage({
    count: 5,
    sizeType: ['original', 'compressed'],
    sourceType: ['album', 'camera'],
    success(res) {
      // tempFilePath可以作为img标签的src属性显示图片
      const tempFilePaths = res.tempFilePaths
      }
  })
  }
}) 