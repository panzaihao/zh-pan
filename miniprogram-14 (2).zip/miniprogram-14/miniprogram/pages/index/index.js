Page({
  data:{
   inputValue1:'',
   inputValue2: '',
   result1:'',
   result2: ''
  },
  textarea1: function (e) {
    var value = e.detail.value;
    console.log(e)
    this.setData({
      inputValue1: value
    })
  },
  textarea2: function (e) {
    var value = e.detail.value;
    console.log(e)
    this.setData({
      inputValue2: value
    })
  },
  bindViewTap: function () {
    wx.navigateTo({
      url: '../photo/photo'
    })
  },
  upload: function () {
    var textarea1 = this.data.inputValue1;
    var textarea2 = this.data.inputValue2;
    var db = wx.cloud.database()
      db.collection("notebook").add({
      data: {
        textarea1: this.data.inputValue1,
        textarea2: this.data.inputValue2,
      },
      success: res => {
        wx.showToast({
          title: '上传成功',
        })
          this.setData({
            counterId: res._id, count: 1
          })
        },
        fail: err => {
          wx.showToast({
            icon: 'none', title: '上传失败',
          })
          console.error('[数据库] [录入记录] 失败：', err)
        },
      })   
  },
  read: function () {
    var that = this;
    wx.cloud.callFunction({
      name: "query",
      success: function (res) {
        var result1 = res.result.data[0].textarea1;
        var result2 = res.result.data[0].textarea2;
      
        wx.showToast({
          title: '读取成功',
        })
        console.log(res)
        that.setData({
          inputValue1: result1,
          inputValue2: result2,
        })
      },
      fail: err => {
        wx.showToast({
          icon: 'none', title: '上传失败',
        })
      }
    })
  },
})