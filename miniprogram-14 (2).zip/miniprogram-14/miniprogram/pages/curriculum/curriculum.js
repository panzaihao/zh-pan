// pages/curriculum/curriculum.js
Page({

  data: {

    colorArrays: ["#85B8CF", "#90C652", "#D8AA5A", "#FC9F9D", "#0A9A84", "#61BC69", "#12AEF3", "#E29AAD"],

    wlist: [

      { "xqj": 1, "skjc": 3, "skcd": 3, "kcmc": "c++程序设计与编程方法@教室：N118" },
      { "xqj": 1, "skjc": 8, "skcd": 2, "kcmc": "综合英语（听说，双周)@教室：N411" },
      { "xqj": 1, "skjc": 12, "skcd": 2, "kcmc": "趣味密码学@教室：S109" },
      { "xqj": 2, "skjc": 1, "skcd": 2, "kcmc": "信息与通信工程导论@教室N103" },
      { "xqj": 2, "skjc": 3, "skcd": 3, "kcmc": "数学分析@教室：N105" },
      { "xqj": 2, "skjc": 9, "skcd":3, "kcmc": "线性代数@教室：N105" },
      { "xqj": 3, "skjc": 1, "skcd": 2, "kcmc": "综合英语@教室：N307" },
    { "xqj": 4, "skjc": 3, "skcd": 2, "kcmc": "心理学/形式与政策@教室：一楼多功能厅" },
      { "xqj": 4, "skjc": 6, "skcd": 3, "kcmc": "数学分析@教室：N105" },
      { "xqj": 4, "skjc": 12, "skcd": 2, "kcmc": "高等数学解题法@教室：S210" },
      { "xqj": 5, "skjc": 1, "skcd": 2, "kcmc": "信息与通信工程导论@教室：N103" },
      { "xqj": 5, "skjc": 3, "skcd": 3, "kcmc": "思修@教室：一楼多功能厅" },
    ]

  }
})