Page({
  data:{
   inputValue1:'',
   inputValue2: '',
   result1:'',
   result2: ''
  },
  onLoad() {
    this.ctx = wx.createCameraContext()
  },
  textarea1: function (e) {
    var value = e.detail.value;
    console.log(e)
    this.setData({
      inputValue1: value
    })
  },
  textarea2: function (e) {
    var value = e.detail.value;
    console.log(e)
    this.setData({
      inputValue2: value
    })
  },
  upload: function () {
    var textarea1 = this.data.inputValue1;
    var textarea2 = this.data.inputValue2;
    var db = wx.cloud.database()
    db.collection("notebook").add({
      data: {
        textarea1: this.data.inputValue1,
        textarea2: this.data.inputValue2,
      },
      success: function (res) {
        console.log(res)
      }
    })
  },
  read: function () {
    var that = this;
    wx.cloud.callFunction({
      name: "query",
      success: function (res) {
        var result1 = res.result.data[4].textarea1;
        var result2 = res.result.data[4].textarea2;
        console.log(res)
        that.setData({
          inputValue1:result1,
          inputValue2:result2,
        })
      }
    })
  },
  src: 'IMG_20190928_222815.jpg',
  takePhoto() {
    this.ctx.takePhoto({
      quality: 'high',
      success: (res) => {
        this.setData({
          src: res.tempImagePath
        })
      }
    })
  },
})